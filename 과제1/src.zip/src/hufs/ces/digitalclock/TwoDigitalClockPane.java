/**
 * Created on Mar 9, 2018
 * @author cskim -- hufs.ac.kr, Dept of CES
 * Copy Right -- Free for Educational Purpose
 */
package hufs.ces.digitalclock;

import java.util.Calendar;
import java.util.Formatter;

import hufs.ces.digitalclock.DigitalClockPaneThread.TimerThread;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

public class TwoDigitalClockPane extends GridPane {

	private Label lblDate1;
	private Label lblDate2;
	private Label lblTime1;
	private Label lblTime2;
	private Button btnStart;
	
	public TwoDigitalClockPane() {
		
		initialize();
	}
	@SuppressWarnings("unchecked")
	void initialize() {
		
		this.setPrefSize(500, 350);
		
		lblDate1 = new Label();
		lblDate1.setPrefWidth(250);
		lblDate1.setPrefHeight(150);
		lblDate1.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
		lblDate1.setTextFill(Color.rgb(0, 128, 0));
		lblDate1.setBackground(new Background(new BackgroundFill(Color.BEIGE, CornerRadii.EMPTY, Insets.EMPTY)));
		lblDate1.setAlignment(Pos.CENTER);
		lblDate1.setTextAlignment(TextAlignment.CENTER);
		this.add(lblDate1, 0, 0);
		
		lblDate2 = new Label();
		lblDate2.setPrefWidth(250);
		lblDate2.setPrefHeight(150);
		lblDate2.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
		lblDate2.setTextFill(Color.rgb(0, 128, 0));
		lblDate2.setBackground(new Background(new BackgroundFill(Color.BEIGE, CornerRadii.EMPTY, Insets.EMPTY)));
		lblDate2.setAlignment(Pos.CENTER);
		lblDate2.setTextAlignment(TextAlignment.CENTER);
		this.add(lblDate2, 1, 0);
		
		lblTime1 = new Label();
		lblTime1.setPrefWidth(250);
		lblTime1.setPrefHeight(150);
		lblTime1.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
		lblTime1.setTextFill(Color.BLUE);
		lblTime1.setAlignment(Pos.CENTER);
		lblTime1.setTextAlignment(TextAlignment.CENTER);
		this.add(lblTime1, 0, 1);

		lblTime2 = new Label();
		lblTime2.setPrefWidth(250);
		lblTime2.setPrefHeight(150);
		lblTime2.setFont(Font.font("Verdana", FontWeight.BOLD, 30));
		lblTime2.setTextFill(Color.BLUE);
		lblTime2.setAlignment(Pos.CENTER);
		lblTime2.setTextAlignment(TextAlignment.CENTER);
		this.add(lblTime2, 1, 1);
		
		btnStart = new Button("Start");
		btnStart.setPrefHeight(50);
		btnStart.setOnAction(e->startAction());	
		btnStart.setPrefWidth(Double.MAX_VALUE);
		this.add(btnStart, 0, 2, 2, 1);
		
		this.heightProperty().addListener((ChangeListener) (observable, oldValue, newValue) -> {
			double height = (double) newValue;
			lblDate1.setPrefHeight(height*3/7);
			lblDate2.setPrefHeight(height*3/7);
			lblTime1.setPrefHeight(height*3/7);
			lblTime2.setPrefHeight(height*3/7);
			btnStart.setPrefHeight(height/7);
		});
		
		this.widthProperty().addListener((ChangeListener) (observable, oldValue, newValue) -> {
			double width = (double) newValue;
			lblDate1.setPrefWidth(width/2);
			lblDate2.setPrefWidth(width/2);
			lblTime1.setPrefWidth(width/2);
			lblTime2.setPrefWidth(width/2);
		});
	}
	void startAction() {
		setDateDisplay1();
	    // Create an animation for a running clock
	    Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), e->setDateDisplay1()));
	    animation.setCycleCount(Timeline.INDEFINITE);
	    animation.play(); // Start animation

		setTimeDisplay1();
	    // Create an animation for a running clock
	    Timeline animation2 = new Timeline(new KeyFrame(Duration.millis(1000), e->setTimeDisplay1()));
	    animation2.setCycleCount(Timeline.INDEFINITE);
	    animation2.play(); // Start animation

		setDateDisplay2();
		Thread th = new TimerThread1();
		th.setDaemon(true);
		th.start();

		setTimeDisplay2();
		Thread th1 = new TimerThread2();
		th1.setDaemon(true);
		th1.start();
	}
	
	void setDateDisplay1(){
		
		Calendar calendar = Calendar.getInstance();

		StringBuilder dateText = new StringBuilder();
		Formatter buildDate = new Formatter(dateText);
		buildDate.format("%1$tY.%1$tm.%1$td", calendar);
		lblDate1.setText(dateText.toString());
	}
	
	void setTimeDisplay1(){
		
		Calendar calendar = Calendar.getInstance();

		StringBuilder dateText = new StringBuilder();
		Formatter buildDate = new Formatter(dateText);
		buildDate.format("%tT", calendar);
		lblTime1.setText(dateText.toString());
	}

	void setDateDisplay2(){

		Platform.runLater(()->{
			Calendar calendar = Calendar.getInstance();

			StringBuilder dateText = new StringBuilder();
			Formatter buildDate = new Formatter(dateText);
			buildDate.format("%1$tY.%1$tm.%1$td", calendar);
			lblDate2.setText(dateText.toString());
		});
	}

	void setTimeDisplay2(){

		Platform.runLater(()->{
			Calendar calendar = Calendar.getInstance();

			StringBuilder dateText = new StringBuilder();
			Formatter buildDate = new Formatter(dateText);
			buildDate.format("%tT", calendar);
			lblTime2.setText(dateText.toString());
		});
	}

	class TimerThread1 extends Thread {

		@Override
		public void run() {
			while (true){
				setDateDisplay2();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	class TimerThread2 extends Thread {

		@Override
		public void run() {
			while (true){
				setTimeDisplay2();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}