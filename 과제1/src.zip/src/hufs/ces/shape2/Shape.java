/**
 * 
 * @author cskim -- hufs.ac.kr 
 * 2016. 4. 7.
 * Copy Right -- Free for Educational Purpose
 *
 */
package hufs.ces.shape2;

/**
 * @author cskim
 *
 */
public interface Shape {
	public double getArea();
	public double getVolume();
	public String getName();
}
